package com.example.tomatech.ui.detection

import android.net.Uri
import androidx.lifecycle.ViewModel

class DetectionViewModel : ViewModel() {
    var currentImageUri: Uri? = null
}